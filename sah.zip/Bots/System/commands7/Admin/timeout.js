const Discord = require('discord.js');
const ms = require("ms");

module.exports = {
  name: "timeout",
  aliases: ["تايم"],
  description: "قم باعطاء وقت مستقطع لعضو مؤقتًا",
  usage: ["!timeout [عضو] [الوقت]"],
  botPermission: ["MANAGE_ROLES"],
  authorPermissions: ["MANAGE_ROLES"],
  cooldowns: [],
  ownerOnly: false,
  run: async (client, message, args) => {
    const member =
      message.mentions.members.first() ||
      (await message.guild.members.fetch(args[0]));

    if (!args[0])
      return message
        .reply({
          content: `❗ **منشن طيب عشان اهفه**`,
        })
        .catch((err) => {
          console.log(`لم أتمكن من الرد على الرسالة: ` + err.message);
        });

    if (!member)
      return message
        .reply({ content: `❗ **لم أتمكن من العثور على هذا العضو**` })
        .catch((err) => {
          console.log(`لم أتمكن من الرد على الرسالة: ` + err.message);
        });

    if (member.id === message.author.id)
      return message
        .reply({ content: `❗ **لا يمكنك استخدام هذا الأمر على نفسك**` })
        .catch((err) => {
          console.log(`لم أتمكن من الرد على الرسالة: ` + err.message);
        });

    if (
      message.member.roles.highest.position < member.roles.highest.position
    )
      return message
        .reply({
          content: `❗ **لا يمكنك اعطاء لشخص اعلى منك ياسبك ${member.user.username} *`,
        })
        .catch((err) => {
          console.log(`لم أتمكن من الرد على الرسالة: ` + err.message);
        });

    if (
      !args[1] ||
      (!args[1].endsWith("s") &&
        !args[1].endsWith("m") &&
        !args[1].endsWith("h") &&
        !args[1].endsWith("d") &&
        !args[1].endsWith("w"))
    ) {
      return message
        .reply({
          content: `❗ **يرجى تقديم وقت صالح بالصيغة [عدد][s/m/h/d/w]**`,
        })
        .catch((err) => {
          console.log(`لم أتمكن من الرد على الرسالة: ` + err.message);
        });
    }

    member
      .timeout(
        ms(args[1]),
        `تم بواسطة: ${message.member.nickname || message.author.username}, ${message.author.id}`
      )
      .then(() => {
        message.reply({
          content: `:white_check_mark: **تم اعطاء وقت مستقطع ${member.user.username} لمدة ${args[1]}**`,
        });
      })
      .catch((err) => {
        message.reply({
          content: `❗ **حدث خطأ أثناء محاولة اعطاء وقت مستقطع هذا العضو. يرجى المحاولة مرة أخرى لاحقًا.**`,
        });
        console.log(
          `حدث خطأ أثناء محاولة اعطاء وقت مستقطع ${member.user.username}: ` +
            err.message
        );
      });
  }
};
