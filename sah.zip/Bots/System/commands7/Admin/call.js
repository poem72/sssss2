const Discord = require('discord.js');

module.exports = {
  name: "call",
  aliases: ["تعديل-الرول"],
  description: "تعديل صلاحيات الرول  .",
  usage: ["!edit-role <role>"],
  botPermission: ["MANAGE_ROLES"],
  authorPermissions: ["MANAGE_ROLES"],
  cooldowns: [],
  ownerOnly: false,
  run: async (client, message, args) => {
    // Check if a role was mentioned
    const roleName = args.join(' ');
    const role = message.guild.roles.cache.find(r => r.name === roleName || r.id === roleName);

    if (!role) {
      return message.reply({ content: "❗ **لم أتمكن من العثور على هذا الرول**" });
    }

    // Define the permissions and their button labels
    const permissions = [
      { name: "Create Instant Invite", value: "CREATE_INSTANT_INVITE" },
      { name: "Kick Members", value: "KICK_MEMBERS" },
      { name: "Ban Members", value: "BAN_MEMBERS" },
      { name: "Administrator", value: "ADMINISTRATOR" },
      { name: "Manage Channels", value: "MANAGE_CHANNELS" },
      { name: "Manage Guild", value: "MANAGE_GUILD" },
      { name: "Add Reactions", value: "ADD_REACTIONS" },
      { name: "View Audit Log", value: "VIEW_AUDIT_LOG" },
      { name: "Priority Speaker", value: "PRIORITY_SPEAKER" },
      { name: "Stream", value: "STREAM" },
      { name: "View Channel", value: "VIEW_CHANNEL" },
      { name: "Send Messages", value: "SEND_MESSAGES" },
      { name: "Send TTS Messages", value: "SEND_TTS_MESSAGES" },
      { name: "Manage Messages", value: "MANAGE_MESSAGES" },
      { name: "Attach Files", value: "ATTACH_FILES" },
      { name: "Read Message History", value: "READ_MESSAGE_HISTORY" },
      { name: "Mention Everyone", value: "MENTION_EVERYONE" },
      { name: "Use External Emojis", value: "USE_EXTERNAL_EMOJIS" },
      { name: "View Guild Insights", value: "VIEW_GUILD_INSIGHTS" },
      { name: "Connect", value: "CONNECT" },
      { name: "Speak", value: "SPEAK" },
      { name: "Mute Members", value: "MUTE_MEMBERS" },
      { name: "Deafen Members", value: "DEAFEN_MEMBERS" },
      { name: "Move Members", value: "MOVE_MEMBERS" },
      { name: "Use VAD", value: "USE_VAD" },
      { name: "Change Nickname", value: "CHANGE_NICKNAME" },
      { name: "Manage Nicknames", value: "MANAGE_NICKNAMES" },
      { name: "Manage Roles", value: "MANAGE_ROLES" },
      { name: "Manage Webhooks", value: "MANAGE_WEBHOOKS" },
      { name: "Manage Emojis and Stickers", value: "MANAGE_EMOJIS_AND_STICKERS" }
    ];

    // Create buttons for each permission
    const buttons = permissions.map(permission => {
      return new Discord.ButtonBuilder()
        .setCustomId(permission.value)
        .setLabel(permission.name)
        .setStyle('PRIMARY');
    });

    // Create a row of buttons
    const buttonRow = new Discord.ActionRowBuilder()
      .addComponents(buttons);

    // Send message with buttons
    const messageEmbed = new Discord.EmbedBuilder()
      .setTitle(`تعديل صلاحيات الرول ${role.name}`)
      .setDescription('اختر الصلاحيات لتعديلها الرول.')
      .setColor('#0099ff');

    const msg = await message.reply({
      embeds: [messageEmbed],
      components: [buttonRow]
    });

    // Create an interaction collector
    const filter = (interaction) => interaction.isButton() && interaction.user.id === message.author.id;
    const collector = msg.createMessageComponentCollector({ filter, time: 60000 });

    // Handle button interactions
    collector.on('collect', async (interaction) => {
      const permission = interaction.customId;

      // Update role permissions
      try {
        const rolePermissions = new Discord.Permissions(role.permissions);
        if (rolePermissions.has(permission)) {
          rolePermissions.remove(permission);
        } else {
          rolePermissions.add(permission);
        }

        await role.edit({ permissions: rolePermissions });
        await interaction.reply({ content: `✔ **تم تحديث صلاحيات الرول ${role.name}**` });
      } catch (error) {
        console.error(`خطأ في تحديث صلاحيات الرول: ${error.message}`);
        await interaction.reply({ content: `❗ **حدث خطأ أثناء تحديث صلاحيات الرول**` });
      }
    });

    collector.on('end', () => {
      msg.edit({ components: [] });
    });
  }
};
