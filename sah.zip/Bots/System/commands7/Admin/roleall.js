const Discord = require('discord.js');

module.exports = {
  name: "roleall",
  aliases: [""],
  description: "تعيين رول لجميع الأعضاء في السيرفر",
  usage: ["!roleall <رول>"],
  botPermission: ["MANAGE_ROLES"],
  authorPermission: ["MANAGE_ROLES"],
  cooldowns: [],
  ownerOnly: false,
  run: async (client, message, args) => {
    if (!args[0]) 
      return message.reply({ content: `❌ **يرجى تحديد الرول الذي تريد إضافته للجميع!**` });

    let role = message.mentions.roles.first() || message.guild.roles.cache.find(r => 
      r.name.toLowerCase().includes(args[0].toLowerCase())) || message.guild.roles.cache.get(args[0]);

    if (!role) 
      return message.reply({ content: `❌ **تعذر العثور على هذا الرول!**` });
      
    if (message.guild.me.roles.highest.position <= role.position)
      return message.reply({ content: `❌ **لا أستطيع إضافة هذا الرول لأنه أعلى/مساوٍ رولي.**` });

    let members = message.guild.members.cache.filter(member => 
      !member.roles.cache.has(role.id) && !member.user.bot);

    if (members.size === 0) {
      return message.reply({ content: `⚠ **جميع الأعضاء لديهم هذا الرول بالفعل أو لا يوجد أعضاء للتعامل معهم!**` });
    }

    members.forEach(member => {
      member.roles.add(role.id).catch(err => console.log(`فشل في إضافة الرول إلى ${member.user.tag}: ${err}`));
    });

    return message.reply({ content: `✔ **تم إعطاء الرول ${role.name} إلى ${members.size} عضو بنجاح!**` });
  }
};
